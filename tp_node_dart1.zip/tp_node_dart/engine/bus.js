import { EventEmitter } from "events";

class Bus extends EventEmitter {

    

}